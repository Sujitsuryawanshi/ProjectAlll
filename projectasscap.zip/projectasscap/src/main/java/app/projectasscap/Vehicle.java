package app.projectasscap;

public abstract class Vehicle {

	abstract void carMame(String name);

	abstract void carColor(String color);
}
