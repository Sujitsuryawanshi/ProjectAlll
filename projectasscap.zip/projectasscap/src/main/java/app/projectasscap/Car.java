package app.projectasscap;

/*
 *  car class Inherited from Abstract Vehicle Class
 *  
 *  Adapter class
 */
public class Car extends Vehicle {
	String name;
	int cost;

	@Override
	void carMame(String name) {
		System.out.println(name);
	}

	@Override
	void carColor(String color) {

		System.out.println(color);

	}

	public String bugget(String modelName, int price) {
		this.name = modelName;
		this.cost = price;

		return null;
	}

	/*
	 * Getter and Setter method 
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int availSensore() {
		return 0;
	}

}
