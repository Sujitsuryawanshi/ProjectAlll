package app.projectasscap;

public class VehicleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     /*
      * reference variable of Carmodel class
      */
		Carmodel c = new Carmodel();
		c.bugget("auddi", 150000);
		c.availSensore(5);
		c.carMame("auddi");
		c.carColor("White");
		
	/*
	 * encapsulation
	 */
		
		Car c1=new Car();
        c1.bugget("Auddi", 150000);
        System.out.println("CarName:- "+c1.getName()+"\nCarCost :- "+c1.getCost());

	}

}
