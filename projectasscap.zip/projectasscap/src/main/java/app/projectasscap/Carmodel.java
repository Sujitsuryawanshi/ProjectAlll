package app.projectasscap;

/*
 * Carmodel class Inherited with Car class
 */
public class Carmodel extends Car {

	@Override
	void carMame(String name) {
		System.out.println("Carname:- "+name);
	}

	@Override
	void carColor(String color) {

		System.out.println("CarColor:- "+color);

	}

	/*
	 * run-time polymorphism
	 */
	public String bugget(String modelName, int price) {
		System.out.println("Carname :- " + modelName + "\nPrice :- " + price);
		return null;
	}

	/*
	 * compile-time polymorphism
	 */

	public int availSensore(int sensor) {
		System.out.println("sensor :- "+sensor);
		return sensor;
	}

}
