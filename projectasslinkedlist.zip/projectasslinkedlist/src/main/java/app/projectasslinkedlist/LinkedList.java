package app.projectasslinkedlist;

//import app.projectasslinkedlist.LinkedList.Node;

// import org.w3c.dom.Node;

public class LinkedList {

	static Node head;

	static class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	//reverse order code
	Node reverse(Node node) {
		Node prev = null;
		Node current = node;
		Node next = null;
		while (current != null) {
			next = current.next;
			current.next = prev;
			prev = current;
			current = next;

		}
		node = prev;
		return node;

	}

	void printList(Node node) {
		while (node != null) {
			System.out.print(node.data + "");
			node = node.next;
		}
	}
	
	public static void main(String[] args) {
		
		LinkedList list=new LinkedList();
		/*
		 * Add element in Linkedlist
		 */
		list.head=new Node(1);
		list.head.next=new Node(2);
		list.head.next.next=new Node(3);
		
		//print the Given Linkedlist
		System.out.println("Given Linked list");
	
		list.printList(head);
		head=list.reverse(head);
		System.out.println("");
		
		// print reverse element int Linkedlist
		System.out.println("Reversed Linked List");
		list.printList(head);
		
		

	}
}
